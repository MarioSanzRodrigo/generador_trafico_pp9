#!/usr/bin/env python

"""

Traffic Generator based on GHOSTs-NPC 

Version: 2.0
Date: 08/03/2022
Author: Mario Sanz Rodrigo.
Contact: mario.sanz@upm.es
Membership: Universidad Politecnica de Madrid

"""
import json
import argparse
import os
import sys
import shutil
import random
import time
from os import listdir
from os.path import isfile, join
import paho.mqtt.client as mqtt #import the client1
import paho.mqtt.publish as publish


broker_address = "localhost"
topic = 'MQTT/topic/10.1.2.1'
#topic = topic_list[0]



def on_message(client, userdata, message):
    x = json.loads(message.payload.decode("utf-8"))
    print(json.dumps(x, indent=4))


client = mqtt.Client("Subscriptor_ejem1")
client.on_message = on_message 
client.connect(broker_address) 
client.loop_start() # Inicio del bucle
client.subscribe(topic)
time.sleep(60) # Paramos el hilo para recibir mensajes.
client.loop_stop() # Fin del bucle

