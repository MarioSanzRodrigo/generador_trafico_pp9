#!/usr/bin/env python

"""

Traffic Generator based on GHOSTs-NPC 

Version: 3.0
Date: 25/05/2022
Author: Mario Sanz Rodrigo.
Contact: mario.sanz@upm.es
Membership: Universidad Politecnica de Madrid

"""

import json
import argparse
import os
import sys
import shutil
import random
import time
import datetime
import pathlib
import paho.mqtt.client as mqtt #import the client1
import paho.mqtt.publish as publish
from vars import *
from commands import *
from os import listdir
from os.path import isfile, join


print('\n\033[1;34m#####################################################################################################')
print('\033[1;37m [COBRA_INFO] Iniciando generador de trafico: \n\tDATE:\t',datetime.datetime.now(),'\n\tEpoch:\t',time.time())
print('\033[1;34m#####################################################################################################')

def list_files(startpath):
	path = str(pathlib.Path().resolve())+'/'
	print('\t',path)
	for root, dirs, files in os.walk(startpath):
		level = root.replace(startpath, '').count(os.sep)
		indent = ' ' * 4 * (level)
		print('\t\t {}{}/'.format(indent, os.path.basename(root)))
		subindent = ' ' * 4 * (level + 1)
		counter_files = 0
		for f in files:
			print('\t\t {}{}'.format(subindent, f))
			counter_files = counter_files + 1
	print('\t[COBRA_INFO]', counter_files, 'ficheros timeline.json generados para cada maquina HOST ')


def get_topic_list(json_file):
	return array_mqtt_topics

def get_topic_file():
	return array_paths_timeline

def countdown(num_of_secs):
    print('\n\033[1;33m Epoch:',time.time(),'\t[COBRA_INFO] Proximo reenvio de ficheros en: ')
    while num_of_secs:
        m, s = divmod(num_of_secs, 60)
        min_sec_format = '{:02d}:{:02d}'.format(m, s)
        print(min_sec_format, end='\r')
        time.sleep(1)
        num_of_secs -= 1
    print('\n')

def orchestration_mqtt():       
    root_path = os.getcwd() + "/MQTT_json_files"
    output_file = root_path+'/listado_timeline.json'

    if os.path.exists(root_path):
        shutil.rmtree(root_path)
        os.makedirs(root_path)
    else:
        os.makedirs(root_path)

    #broker_address = "10.1.3.243"
    broker_address = "localhost"
    array_ficheros_mqtt = []

    data = {}
    data['vms_npc'] = []

    with open(sys.argv[1]) as json_data:
        d = json.load(json_data)

    topic_list = get_topic_list(d)
    timeline_files = get_topic_file()

    aux = 0

    for i in timeline_files:

        onlyfiles = [i+"/"+f for f in listdir(i) if isfile(join(i, f))]

        data['vms_npc'].append({
            'name': array_vms_npc[aux],
            'file': onlyfiles,
            'topic': topic_list[aux]
            })

        aux = aux + 1

    # Obtengo JSON de ficheros Timeline con su path absoluto.

    with open(output_file, 'w') as file:
        json.dump(data, file, indent=4)

    with open(output_file) as json_data:
        mqtt_file = json.load(json_data)

    while True:
        for vms_npc in mqtt_file:
            for vm_id in mqtt_file[vms_npc]:
                print('\n\033[1;32mEpoch:',time.time(),'\t[COBRA_INFO] Envio aleatorio de fichero de comportamiento a la maquina', vm_id['name'])
                print("\033[1;37m - Maquina NPC: ",vm_id['name'])
                print("\033[1;37m - Topic MQTT:  ",vm_id['topic'])
                rand_id = random.randint(0,len(vm_id['file'])-1)
                print("\033[1;37m - Fichero:     ",vm_id['file'][rand_id][-14:])

                f = open(vm_id['file'][rand_id])
                timeline_json = json.load(f)

                publish.single(vm_id['topic'], json.dumps(timeline_json), hostname=broker_address,client_id='publicador_ejem2.py')

        countdown(mqtt_timesleep)


def parser(json_topology_file):

	print('\n\033[1;33m Epoch:',time.time(),'\t[COBRA_INFO] Iniciando el parseo del fichero de topologia')

	# Creacion del arbol de directorios para depositar los ficheros timeline.json
	for scenario in json_topology_file:

		if os.path.exists(scenario):
			shutil.rmtree(scenario)
			os.makedirs(scenario)

		if not os.path.exists(scenario):
			os.makedirs(scenario)

		for vlans in d[scenario]:
			os.mkdir(scenario+"/"+vlans)

			# Bucle para obtener la IP del servidor o servidores de esa VLAN
			for (key,val) in d[scenario][vlans].items():
				aux = json.loads(json.dumps(val, indent = 4))
				if aux["vm_type"] == "SERVER":
					ip_servidor = aux["ip_address"]

			# Bucle para la creacion de carpetas individuales asociadas a cada maquina HOST
			for (key,val) in d[scenario][vlans].items():
				aux = json.loads(json.dumps(val, indent = 4))

				# Condicion, si la maquina es tipo SERVER no genera fichero de comportamiento timeline.json
				if aux["vm_type"] == "SERVER":
					continue;

				os.mkdir(scenario+"/"+"/"+vlans+"/"+aux["vm_name"])
				array_paths_timeline.append(os.getcwd()+"/"+scenario+"/"+vlans+"/"+aux["vm_name"])
				array_vms_npc.append(aux["vm_name"])

				# Bucle para la creacion de N ficheros de comportamiento timeline.json
				array_mqtt_topics.append("MQTT/topic/"+aux["ip_address"])

				for i in range(num_timeline_files):

					timeline = json.dumps(timeline_base, indent = 4)
					dict_timeline = json.loads(timeline)

					# Agregada instruccion de evento vacia

					event = json.dumps(event_base, indent = 4)
					dict_event = json.loads(event)


					# NOTA: Descomentar bloque completo si se quiere desligar los comandos ICMP y NMAP al array de servicios del JSON de topologia

					# for ip in aux["reachable_vms"]:
						# Comentar random.randint para evitar aleatoriedad de comandos
						#if random.randint(0,1)==1:
						# if 1==0:
						# 	for j in range(3):
						# 		traffic_gen_ping(aux,dict_timeline,event_base,rand_ping_min,rand_ping_max,\
						# 			rand_delayafter_start,rand_delayafter_stop,rand_delaybefore_start,\
						# 			rand_delaybefore_stop,counter_ip)

						# traffic_gen_nmap(aux,dict_timeline,event_base,\
						# 	rand_delayafter_start,rand_delayafter_stop,rand_delaybefore_start,\
						# 	rand_delaybefore_stop,counter_ip)

					if aux["vm_type"] == "HOST":
						counter_service = 0

						# Comentar random.randint para evitar aleatoriedad de comandos
						for service in aux["services_in_vm"]:

							###############################################################################################
							################################ [COBRA] Trafico interactivo ##################################
							###############################################################################################

							if service == "WEB": #OK
								if random.randint(0,1)==1:
									traffic_gen_http_1(aux["os_type"],dict_timeline,event_base,ip_servidor,rand_delayafter_start,\
										rand_delayafter_stop,rand_delaybefore_start,rand_delaybefore_stop,counter_service)								
									traffic_gen_http_2(aux["os_type"],dict_timeline,event_base,ip_servidor,rand_delayafter_start,\
										rand_delayafter_stop,rand_delaybefore_start,rand_delaybefore_stop,counter_service)

							elif service == "MQTT": #TODO
								if random.randint(0,1)==1:
									traffic_gen_mqtt(aux["os_type"],dict_timeline,event_base,ip_servidor,rand_delayafter_start,\
										rand_delayafter_stop,rand_delaybefore_start,rand_delaybefore_stop,counter_service)

							elif service == "SNMP": #OK
								if random.randint(0,1)==1:
									traffic_gen_snmp(aux["os_type"],dict_timeline,event_base,ip_servidor,rand_delayafter_start,\
										rand_delayafter_stop,rand_delaybefore_start,rand_delaybefore_stop,counter_service)

							elif service == "ICMP_PING": #OK
								counter_ip = 0
								#if random.randint(0,1)==1:
								if 1==1:
									for ip in aux["reachable_vms"]:
										traffic_gen_ping(aux["os_type"],aux,dict_timeline,event_base,rand_ping_min,rand_ping_max,\
											rand_delayafter_start,rand_delayafter_stop,rand_delaybefore_start,\
											rand_delaybefore_stop,counter_ip)
										counter_ip = counter_ip + 1

							elif service == "ICMP_TRACE": #TODO
								counter_ip = 0
								if random.randint(0,1)==1:
								#if 1==1:
									for ip in aux["reachable_vms"]:
										#for j in range(len(aux["reachable_vms"])):
										traffic_gen_traceroute(aux["os_type"],aux,dict_timeline,event_base,rand_ping_min,rand_ping_max,\
											rand_delayafter_start,rand_delayafter_stop,rand_delaybefore_start,\
											rand_delaybefore_stop,counter_ip)
										counter_ip = counter_ip + 1

							elif service == "REMOTE_SSH": #OK
								if random.randint(0,1)==1:
								#if 1==1:
									traffic_gen_ssh(aux["os_type"],dict_timeline,event_base,ip_servidor,rand_delayafter_start,\
										rand_delayafter_stop,rand_delaybefore_start,rand_delaybefore_stop,counter_service)

									traffic_gen_ssh(aux["os_type"],dict_timeline,event_base,ip_servidor,rand_delayafter_start,\
										rand_delayafter_stop,rand_delaybefore_start,rand_delaybefore_stop,counter_service)

							elif service == "REMOTE_SCP": #OK
								if random.randint(0,1)==1:
									traffic_gen_scp(aux["os_type"],dict_timeline,event_base,ip_servidor,rand_delayafter_start,\
										rand_delayafter_stop,rand_delaybefore_start,rand_delaybefore_stop,counter_service)

							elif service == "NMAP": #OK
								counter_ip = 0
								if random.randint(0,1)==1:
								#if 1==1:
									for ip in aux["reachable_vms"]:
										traffic_gen_nmap(aux["os_type"],aux,dict_timeline,event_base,\
											rand_delayafter_start,rand_delayafter_stop,rand_delaybefore_start,\
											rand_delaybefore_stop,counter_ip)
										counter_ip = counter_ip + 1


							###############################################################################################
							################################ [COBRA] Trafico elastico #####################################
							###############################################################################################	

							elif service == "MAIL":
								if random.randint(0,1)==1:
									traffic_gen_smtp(aux["os_type"],dict_timeline,event_base,ip_servidor,rand_delayafter_start,\
										rand_delayafter_stop,rand_delaybefore_start,rand_delaybefore_stop,counter_service)

							elif service == "MAIL_FILE_POSTFIX":
								if random.randint(0,1)==1:
									traffic_gen_file_smpt(aux["os_type"],dict_timeline,event_base,ip_servidor,rand_delayafter_start,\
										rand_delayafter_stop,rand_delaybefore_start,rand_delaybefore_stop,counter_service)

							elif service == "MAIL_FILE_SSH":
								if random.randint(0,1)==1:
									traffic_gen_file_ssh(aux["os_type"],dict_timeline,event_base,ip_servidor,rand_delayafter_start,\
										rand_delayafter_stop,rand_delaybefore_start,rand_delaybefore_stop,counter_service)

							elif service == "BBDD_POSTGRES":
								if random.randint(0,1)==1:
									traffic_gen_bbdd_postgres(aux["os_type"],dict_timeline,event_base,ip_servidor,rand_delayafter_start,\
										rand_delayafter_stop,rand_delaybefore_start,rand_delaybefore_stop,counter_service)

							elif service == "BBDD_MYSQL":
								if random.randint(0,1)==1:
									traffic_gen_bbdd_mysql(aux["os_type"],dict_timeline,event_base,ip_servidor,rand_delayafter_start,\
										rand_delayafter_stop,rand_delaybefore_start,rand_delaybefore_stop,counter_service)

							elif service == "BBDD_MONGO":
								if random.randint(0,1)==1:
									traffic_gen_bbdd_mongo(aux["os_type"],dict_timeline,event_base,ip_servidor,rand_delayafter_start,\
										rand_delayafter_stop,rand_delaybefore_start,rand_delaybefore_stop,counter_service)

							###############################################################################################
							################################ [COBRA] Trafico streaming ####################################
							###############################################################################################

							elif service == "STREAMING_RTP":
								if random.randint(0,1)==1:
									traffic_gen_streaming_1(aux["os_type"],dict_timeline,event_base,ip_servidor,rand_delayafter_start,\
										rand_delayafter_stop,rand_delaybefore_start,rand_delaybefore_stop,counter_service)

							elif service == "STREAMING_HTTP":
								if random.randint(0,1)==1:
									traffic_gen_streaming_2(aux["os_type"],dict_timeline,event_base,ip_servidor,rand_delayafter_start,\
										rand_delayafter_stop,rand_delaybefore_start,rand_delaybefore_stop,counter_service)

							###############################################################################################
							################################ [COBRA] Trafico conversacional ###############################
							###############################################################################################

							elif service == "VoIP":
								if random.randint(0,1)==1:
									traffic_gen_voip(aux["os_type"],dict_timeline,event_base,ip_servidor,rand_delayafter_start,\
										rand_delayafter_stop,rand_delaybefore_start,rand_delaybefore_stop,counter_service)

							elif service == "VIDEO_CONFERENCE":
								if random.randint(0,1)==1:
									traffic_gen_videoconference(aux["os_type"],dict_timeline,event_base,ip_servidor,rand_delayafter_start,\
										rand_delayafter_stop,rand_delaybefore_start,rand_delaybefore_stop,counter_service)

							elif service == "REMOTE_DESKTOP":
								if random.randint(0,1)==1:
									traffic_gen_remote_desktop(aux["os_type"],dict_timeline,event_base,ip_servidor,rand_delayafter_start,\
										rand_delayafter_stop,rand_delaybefore_start,rand_delaybefore_stop,counter_service)


					with open(scenario+"/"+"/"+vlans+"/"+aux["vm_name"]+"/"+'timeline'+str(i)+'.json', 'w') as f:
						json.dump(dict_timeline, f, indent=4)

				print('\033[1;32m Epoch:',time.time(),'\t[COBRA_INFO] Finalizado el parseo del fichero de topologia')
				print('\033[1;32m Epoch:',time.time(),'\t[COBRA_INFO] Creados los ficheros de comportamiento timeline\n')
				print('\033[1;32m - Path ficheros timeline:')
				list_files(scenario)


with open(sys.argv[1]) as f:
	d = json.load(f)

for scenario in d:
	for vlans in d[scenario]:
		for vm in d[scenario][vlans]:
			if len(d[scenario][vlans][vm]["services_in_vm"]) == 0:
				d[scenario][vlans][vm]["vm_type"] = "HOST"
			else:
				d[scenario][vlans][vm]["vm_type"] = "SERVER"

for scenario in d: 
	for vlans in d[scenario]:
		for vm in d[scenario][vlans]:
			if d[scenario][vlans][vm]["vm_type"] == "SERVER":
				services_in_server = d[scenario][vlans][vm]["services_in_vm"]
		for vm in d[scenario][vlans]:
			if d[scenario][vlans][vm]["vm_type"] == "HOST":
				d[scenario][vlans][vm]["services_in_vm"] = services_in_server


with open('json.json', 'w') as outfile:
	json.dump(d, outfile, indent = 4)


with open('json.json') as json_data:
 	d = json.load(json_data)
 	parser(d)

orchestration_mqtt()


