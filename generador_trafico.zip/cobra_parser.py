#!/usr/bin/env python

"""

Traffic Generator based on GHOSTs-NPC 

Version: 2.0
Date: 08/03/2022
Author: Mario Sanz Rodrigo.
Contact: mario.sanz@upm.es
Membership: Universidad Politecnica de Madrid

"""

import json
import argparse
import os
import sys
import shutil
import random
from vars import *
from commands import *


with open(sys.argv[1]) as json_data:
    d = json.load(json_data)


def get_topic_list(json_file):

	return array_mqtt_topics

def get_topic_file():

	return array_paths_timeline


# Creacion del arbol de directorios
for scenario in d:

	if os.path.exists(scenario):
		shutil.rmtree(scenario)
		os.makedirs(scenario)

	if not os.path.exists(scenario):
		os.makedirs(scenario)

	for vlans in d[scenario]:
		os.mkdir(scenario+"/"+vlans)

		# BUCLE PARA OBTENER LA IP del SERVIDOR o SERVIDORES DE ESA VLAN
		for (key,val) in d[scenario][vlans].items():
			aux = json.loads(json.dumps(val, indent = 4))
			if aux["type_of_vm"] == "SERVER":
				ip_servidor = aux["ip_dir"]

		# BUCLE PARA LA CREACION DE LAS CARPETAS INDIVIDUALES POR MAQUINA
		for (key,val) in d[scenario][vlans].items():
			aux = json.loads(json.dumps(val, indent = 4))

			# CONDICION, SI LA MAQUINA ES SERVER NO GENERA FICHERO COMPORTAMIENTO TIMELINE
			if aux["type_of_vm"] == "SERVER":
				continue;

			os.mkdir(scenario+"/"+"/"+vlans+"/"+aux["vm_name"])
			array_paths_timeline.append(os.getcwd()+"/"+scenario+"/"+vlans+"/"+aux["vm_name"])
			array_vms_npc.append(aux["vm_name"])


			# BUCLE PARA LA CREACION DE N FICHEROS DE COMPORTAMIENTO
			array_mqtt_topics.append("MQTT/topic/"+aux["ip_dir"])

			for i in range(num_timeline_files):
				counter_ip = 0

				timeline = json.dumps(timeline_base, indent = 4)
				dict_timeline = json.loads(timeline)

				# Agregada instruccion de evento vacia

				event = json.dumps(event_base, indent = 4)
				dict_event = json.loads(event)


				for ip in aux["accesibles_vms"]:
					# Comentar random.randint para evitar aleatoriedad de comandos
					#if random.randint(0,1)==1:
					if 1==0:
						for j in range(3):
							traffic_gen_ping(aux,dict_timeline,event_base,rand_ping_min,rand_ping_max,\
								rand_delayafter_start,rand_delayafter_stop,rand_delaybefore_start,\
								rand_delaybefore_stop,counter_ip)

					traffic_gen_nmap(aux,dict_timeline,event_base,\
						rand_delayafter_start,rand_delayafter_stop,rand_delaybefore_start,\
						rand_delaybefore_stop,counter_ip)

				if aux["type_of_vm"] == "HOST":
					counter_service = 0

					#array_mqtt_topics.append("MQTT/topic/"+aux["ip_dir"])
					#if aux["type_of_OS"] == "LINUX":
						#print(unix_command_ping)

					# Comentar random.randint para evitar aleatoriedad de comandos
					for service in aux["services_in_vm"]:
						if service == "HTTP":
							if random.randint(0,1)==1:
								traffic_gen_http_1(dict_timeline,event_base,ip_servidor,rand_delayafter_start,\
									rand_delayafter_stop,rand_delaybefore_start,rand_delaybefore_stop,counter_service)

						elif service == "HTTPS":
							if random.randint(0,1)==1:
								traffic_gen_http_2(dict_timeline,event_base,ip_servidor,rand_delayafter_start,\
									rand_delayafter_stop,rand_delaybefore_start,rand_delaybefore_stop,counter_service)

						elif service == "SNMP":
							if random.randint(0,1)==1:
								traffic_gen_snmp(dict_timeline,event_base,ip_servidor,rand_delayafter_start,\
									rand_delayafter_stop,rand_delaybefore_start,rand_delaybefore_stop,counter_service)

						elif service == "SSH":
							if random.randint(0,1)==1:
								traffic_gen_ssh(dict_timeline,event_base,ip_servidor,rand_delayafter_start,\
									rand_delayafter_stop,rand_delaybefore_start,rand_delaybefore_stop,counter_service)

								traffic_gen_ssh(dict_timeline,event_base,ip_servidor,rand_delayafter_start,\
									rand_delayafter_stop,rand_delaybefore_start,rand_delaybefore_stop,counter_service)

						elif service == "SCP":
							if random.randint(0,1)==1:
								traffic_gen_scp(dict_timeline,event_base,ip_servidor,rand_delayafter_start,\
									rand_delayafter_stop,rand_delaybefore_start,rand_delaybefore_stop,counter_service)

						elif service == "SMTP":
							if random.randint(0,1)==1:
								traffic_gen_smtp(dict_timeline,event_base,ip_servidor,rand_delayafter_start,\
									rand_delayafter_stop,rand_delaybefore_start,rand_delaybefore_stop,counter_service)

				with open(scenario+"/"+"/"+vlans+"/"+aux["vm_name"]+"/"+'timeline'+str(i)+'.json', 'w') as f:
					json.dump(dict_timeline, f, indent=4)


#print(array_mqtt_topics)
#print(array_paths_timeline)


