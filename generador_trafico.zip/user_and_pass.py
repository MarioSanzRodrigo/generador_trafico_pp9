#!/usr/bin/env python

"""

Traffic Generator based on GHOSTs-NPC 

Version: 3.0
Date: 25/05/2022
Author: Mario Sanz Rodrigo.
Contact: mario.sanz@upm.es
Membership: Universidad Politecnica de Madrid

"""

# Usuario comun para todas las maquinas

mgmt_user = 'Generador_trafico'
mgmt_pass = '!cobra1234'

# Usuario y password para servicio PostgreSQL

bbdd_postgres_user = 'postgres'
bbdd_postgres_pass = '1234'
postgres_table = 'empleados'
postgres_port = '5432'

# Usuario y password para servicio MySQL

bbdd_mysql_user = 'root'
bbdd_mysql_pass = '1234'
mysql_database = 'cobra_test'
mysql_table = 'empleados'
mysql_port = '3306'