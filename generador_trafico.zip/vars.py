#!/usr/bin/env python

"""

Traffic Generator based on GHOSTs-NPC 

Version: 3.0
Date: 25/05/2022
Author: Mario Sanz Rodrigo.
Contact: mario.sanz@upm.es
Membership: Universidad Politecnica de Madrid

"""

from user_and_pass import *

# Vars

# JSON base para el Timeline de GHOSTS

timeline_base = {
	"Id": "50e666f6-24f9-4cf7-907a-f28a8cf90d32",
	"Status": "Run",
	"TimeLineHandlers": [
	{
			"HandlerType": "Command",
			"Initial": "",
			"UtcTimeOn": "00:00:00",
			"UtcTimeOff": "24.00:00:00",
			"Loop": False,
			"TimeLineEvents": []
		}]
}

event_base = {
	"TrackableId": "null",
	"Command": "",
	"CommandArgs": [],
	"DelayAfter": 0,
	"DelayBefore": 0
}


# Tiempo de reeenvio de ficheros timeline (sec)
mqtt_timesleep = 30

array_vlans = []
array_vlans_id = []
array_servers = []
array_mqtt_topics = []
array_paths_timeline = []
array_vms_npc = []

# Numero de ficheros timeline generados
num_timeline_files = 10

rand_delayafter_start = 0
rand_delayafter_stop = 100

rand_delaybefore_start = 0
rand_delaybefore_stop = 100

rand_ping_min = 3
rand_ping_max = 5


##################################################################################################
################################## [COBRA] Trafico interactivo TEST sobre UNIX ###################
##################################################################################################

http_command_1 = "curl "
http_command_2 = "wget "
mqtt_command = "@TODO no implementado"
snmp_command = "snmpwalk "
ping_command = "ping -c "
traceroute_command = "traceroute "
ssh_command = "sshpass -p " + mgmt_pass + " ssh -o StrictHostKeyChecking=no " + mgmt_user +"@"
scp_command = "sshpass -p " + mgmt_pass + " scp /home/" + mgmt_user + "/prueba.txt " + mgmt_user + "@"
nmap_command = "nmap"

##################################################################################################
################################## [COBRA] Trafico elastico TEST sobre UNIX ######################
##################################################################################################

smtp_command = "smpt "
smtp_file_command = "@TODO no implementado"
ssh_file_command = "@TODO no implementado"

def bbdd_postgres_command(ip_servidor):
	bbdd_postgres_command = "PGPASSWORD="+bbdd_postgres_pass+" psql -h "+ ip_servidor + " -P " + \
	postgres_port + "-U " + bbdd_postgres_user + " -e 'select * from " + postgres_table + "'"

	return bbdd_postgres_command

def bbdd_mysql_command(ip_servidor):
	bbdd_mysql_command = "mysql -u " + bbdd_mysql_user + " --password=" + bbdd_mysql_pass + " -h " + \
	ip_servidor + " -P " + mysql_port + " " + mysql_database + " -e 'select * from " + mysql_table + ";'"

	return bbdd_mysql_command

bbdd_mongo_command = "@TODO no implementado"

##################################################################################################
################################## [COBRA] Trafico streaming TEST sobre UNIX #####################
##################################################################################################

streaming_1_command = "@TODO no implementado"
streaming_2_command = "@TODO no implementado"

##################################################################################################
################################## [COBRA] Trafico conversacional TEST sobre UNIX ################
##################################################################################################

voip_command = "@TODO no implementado"
videoconference_command = "@TODO no implementado"
remote_desktop_command = "@TODO no implementado"


################################################################################################
################################## [COBRA] Trafico interactivo WINDOWS #########################
################################################################################################

win_http_command_1 = "curl "
win_http_command_2 = "@TODO wget no disponible en windows"
win_mqtt_command = "@TODO no implementado"
win_snmp_command = "@TODO no implementado"
win_ping_command = "ping -n "
win_traceroute_command = "tracert "
win_ssh_command = "ssh " + mgmt_user + "@"
win_scp_command = "@TODO no implementado"
win_nmap_command = "@TODO no implementado"

################################################################################################
################################## [COBRA] Trafico elastico WINDOWS ############################
################################################################################################

win_smtp_command = "@TODO no implementado"
win_smtp_file_command = "@TODO no implementado"
win_ssh_file_command = "@TODO no implementado"
win_bbdd_postgres_command = "@TODO no implementado"
win_bbdd_mysql_command = "@TODO no implementado"
win_bbdd_mongo_command = "@TODO no implementado"

################################################################################################
################################## [COBRA] Trafico streaming WINDOWS ###########################
################################################################################################

win_streaming_1_command = "@TODO no implementado"
win_streaming_2_command = "@TODO no implementado"

################################################################################################
################################## [COBRA] Trafico conversacional WINDOWS ######################
################################################################################################

win_voip_command = ""
win_videoconference_command = "@TODO no implementado"
win_remote_desktop_command = "@TODO no implementado"

################################################################################################
################################## [COBRA] Trafico interactivo UNIX ############################
################################################################################################

unix_http_command_1 = "curl "
unix_http_command_2 = "wget "
unix_mqtt_command = "@TODO no implementado"
unix_snmp_command = "snmpwalk "
unix_ping_command = "ping -c "
unix_traceroute_command = "traceroute "
unix_ssh_command = "sshpass -p " + mgmt_pass + " ssh -o StrictHostKeyChecking=no " + mgmt_user +"@"
unix_scp_command = "sshpass -p " + mgmt_pass + " scp /home/"+mgmt_user+"/prueba.txt " + mgmt_user + "@"
unix_nmap_command = "nmap"

################################################################################################
################################## [COBRA] Trafico elastico UNIX ###############################
################################################################################################

unix_smtp_command = "@TODO no implementado"
unix_smtp_file_command = "@TODO no implementado"
unix_ssh_file_command = "@TODO no implementado"

def unix_bbdd_postgres_command(ip_servidor):
	unix_bbdd_postgres_command = "PGPASSWORD="+bbdd_postgres_pass+" psql -h "+ ip_servidor + " -P " + \
	postgres_port + "-U " + bbdd_postgres_user + " -e 'select * from " + postgres_table + "'"

	return unix_bbdd_postgres_command

def unix_bbdd_mysql_command(ip_servidor):
	unix_bbdd_mysql_command = "mysql -u " + bbdd_mysql_user + " --password=" + bbdd_mysql_pass + " -h " + \
	ip_servidor + " -P " + mysql_port + " " + mysql_database + " -e 'select * from " + mysql_table + ";'"

	return unix_bbdd_mysql_command

unix_bbdd_mongo_command = "@TODO no implementado"

################################################################################################
################################## [COBRA] Trafico streaming UNIX ##############################
################################################################################################

unix_streaming_1_command = "@TODO no implementado"
unix_streaming_2_command = "@TODO no implementado"

################################################################################################
################################## [COBRA] Trafico conversacional UNIX #########################
################################################################################################

unix_voip_command = "@TODO no implementado"
unix_videoconference_command = "@TODO no implementado"
unix_remote_desktop_command = "@TODO no implementado"

