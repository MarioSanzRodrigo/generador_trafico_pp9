#!/usr/bin/env python

"""

Traffic Generator based on GHOSTs-NPC 

Version: 2.0
Date: 08/03/2022
Author: Mario Sanz Rodrigo.
Contact: mario.sanz@upm.es
Membership: Universidad Politecnica de Madrid

"""
import json
import argparse
import os
import sys
import shutil
import random
import time
from os import listdir
from os.path import isfile, join
from vars import *
from cobra_parser import *
import paho.mqtt.client as mqtt #import the client1
import paho.mqtt.publish as publish

def countdown(num_of_secs):
    print('\n[COBRA_INFO] Proximo reenvio de ficheros en: ')
    while num_of_secs:
        m, s = divmod(num_of_secs, 60)
        min_sec_format = '{:02d}:{:02d}'.format(m, s)
        print(min_sec_format, end='\r')
        time.sleep(1)
        num_of_secs -= 1
    print('\n')
        
root_path = os.getcwd() + "/MQTT_json_files"
output_file = root_path+'/listado_timeline.json'

if os.path.exists(root_path):
    shutil.rmtree(root_path)
    os.makedirs(root_path)
else:
    os.makedirs(root_path)

#broker_address = "10.1.3.243"
broker_address = "localhost"
array_ficheros_mqtt = []

data = {}
data['vms_npc'] = []

with open(sys.argv[1]) as json_data:
    d = json.load(json_data)

topic_list = get_topic_list(d)
timeline_files = get_topic_file()

aux = 0

for i in timeline_files:

    onlyfiles = [i+"/"+f for f in listdir(i) if isfile(join(i, f))]

    data['vms_npc'].append({
        'name': array_vms_npc[aux],
        'file': onlyfiles,
        'topic': topic_list[aux]
        })

    aux = aux + 1

# Obtengo JSON de ficheros Timeline con su path absoluto.

with open(output_file, 'w') as file:
    json.dump(data, file, indent=4)

with open(output_file) as json_data:
    mqtt_file = json.load(json_data)


while True:
    for vms_npc in mqtt_file:
        for vm_id in mqtt_file[vms_npc]:
            print("\n[COBRA_INFO] Envio aleatorio de fichero de comportamiento a la maquina", vm_id['name'])
            print(" - Maquina NPC: ",vm_id['name'])
            print(" - Topic MQTT:  ",vm_id['topic'])
            rand_id = random.randint(0,len(vm_id['file'])-1)
            print(" - Fichero:     ",vm_id['file'][rand_id][-14:])

            f = open(vm_id['file'][rand_id])
            timeline_json = json.load(f)

            publish.single(vm_id['topic'], json.dumps(timeline_json), hostname=broker_address,client_id='publicador_ejem2.py')

    countdown(mqtt_timesleep)
    #time.sleep(mqtt_timesleep)
    #print("\n Esperando ",mqtt_timesleep," segundos para el proximo envio")

            #print(len(vm_id['file']))
            #for ghost_file in vm_id['file']:
            #    if random.randint(0,1)==1:
            #        print(ghost_file)


