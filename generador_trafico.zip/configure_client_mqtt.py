#!/usr/bin/env python

"""

Traffic Generator based on GHOSTs-NPC 

Version: 2.0
Date: 08/03/2022
Author: Mario Sanz Rodrigo.
Contact: mario.sanz@upm.es
Membership: Universidad Politecnica de Madrid

"""

import netifaces as ni


interface = 'enp0s3'
mqtt_broker = 133


def search_string_in_file(file_name, string_to_search):
    line_number = 0
    list_of_results = []
    with open(file_name, 'r') as read_obj:
        for line in read_obj:
            line_number += 1
            if string_to_search in line:
                list_of_results.append((line_number, line.rstrip()))

    return list_of_results

matched_lines = search_string_in_file('cobra_ghosts.cfg', 'MQTT_TOPIC=')

for elem in matched_lines:
    line = elem[0]


ip_client = ni.ifaddresses(interface)[ni.AF_INET][0]['addr']
ip_server = ip_client[:ip_client.rfind(".")] + '.' + str(mqtt_broker)



# Configuracion TOPIC en el cliente
with open('cobra_ghosts.cfg', 'r', encoding='utf-8') as file:
    data = file.readlines()
  
data[line-1] = 'MQTT_TOPIC=MQTT/topic/'+ip_client+'\n'
  
with open('cobra_ghosts.cfg', 'w', encoding='utf-8') as file:
    file.writelines(data)


# Configuracion de la IP server MQTT (IP reservada)
matched_lines = search_string_in_file('cobra_ghosts.cfg', 'BROKER_ADDR=')

for elem in matched_lines:
    line = elem[0]

with open('cobra_ghosts.cfg', 'r', encoding='utf-8') as file:
    data = file.readlines()
  
data[line-1] = 'BROKER_ADDR='+ip_server+'\n'
  
with open('cobra_ghosts.cfg', 'w', encoding='utf-8') as file:
    file.writelines(data)