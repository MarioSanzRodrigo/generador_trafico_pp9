#!/usr/bin/env python

"""

Traffic Generator based on GHOSTs-NPC 

Version: 3.0
Date: 25/05/2022
Author: Mario Sanz Rodrigo.
Contact: mario.sanz@upm.es
Membership: Universidad Politecnica de Madrid

"""
import json
import random
from vars import *

# Command functions

#################################################################################################
################################## [COBRA] Trafico interactivo ##################################
#################################################################################################


#@TODO
def traffic_gen_http_1(type_OS,dict_timeline,event_base,ip_servidor,rand_delayafter_start,\
	rand_delayafter_stop,rand_delaybefore_start,rand_delaybefore_stop,counter_service):

	if type_OS == 'LINUX':
		event_base["Command"]= unix_http_command_1 + ip_servidor
	elif type_OS == 'WINDOWS':
		event_base["Command"]= win_http_command_1 + ip_servidor
	elif type_OS == 'TEST':
		event_base["Command"]= http_command_1 + ip_servidor

	event_base["DelayAfter"]= random.randint(rand_delayafter_start,rand_delayafter_stop)
	event_base["DelayBefore"]= random.randint(rand_delaybefore_start,rand_delaybefore_stop)
	
	counter_service = counter_service + 1
	
	event = json.dumps(event_base, indent = 4)
	dict_event = json.loads(event)

	dict_timeline["TimeLineHandlers"][0]["TimeLineEvents"].append(dict_event)

	return

#@TODO
def traffic_gen_http_2(type_OS,dict_timeline,event_base,ip_servidor,rand_delayafter_start,\
	rand_delayafter_stop,rand_delaybefore_start,rand_delaybefore_stop,counter_service):

	if type_OS == 'LINUX':
		event_base["Command"]= unix_http_command_2 + ip_servidor
	elif type_OS == 'WINDOWS':
		event_base["Command"]= win_http_command_2 + ip_servidor
	elif type_OS == 'TEST':
		event_base["Command"]= http_command_2 + ip_servidor

	event_base["DelayAfter"]= random.randint(rand_delayafter_start,rand_delayafter_stop)
	event_base["DelayBefore"]= random.randint(rand_delaybefore_start,rand_delaybefore_stop)
	
	counter_service = counter_service + 1
	
	event = json.dumps(event_base, indent = 4)
	dict_event = json.loads(event)

	dict_timeline["TimeLineHandlers"][0]["TimeLineEvents"].append(dict_event)

	return

def traffic_gen_mqtt(type_OS,dict_timeline,event_base,ip_servidor,rand_delayafter_start,\
	rand_delayafter_stop,rand_delaybefore_start,rand_delaybefore_stop,counter_service):

	if type_OS == 'LINUX':
		event_base["Command"]= unix_mqtt_command + ip_servidor
	elif type_OS == 'WINDOWS':
		event_base["Command"]= win_mqtt_command + ip_servidor
	elif type_OS == 'TEST':
		event_base["Command"]= mqtt_command + ip_servidor

	event_base["DelayAfter"]= random.randint(rand_delayafter_start,rand_delayafter_stop)
	event_base["DelayBefore"]= random.randint(rand_delaybefore_start,rand_delaybefore_stop)
	
	counter_service = counter_service + 1
	
	event = json.dumps(event_base, indent = 4)
	dict_event = json.loads(event)

	dict_timeline["TimeLineHandlers"][0]["TimeLineEvents"].append(dict_event)

	return

#@TODO
def traffic_gen_snmp(type_OS,dict_timeline,event_base,ip_servidor,rand_delayafter_start,\
	rand_delayafter_stop,rand_delaybefore_start,rand_delaybefore_stop,counter_service):

	if type_OS == 'LINUX':
		event_base["Command"]= unix_snmp_command + ip_servidor
	elif type_OS == 'WINDOWS':
		event_base["Command"]= win_snmp_command + ip_servidor
	elif type_OS == 'TEST':
		event_base["Command"]= snmp_command + ip_servidor

	event_base["DelayAfter"]= random.randint(rand_delayafter_start,rand_delayafter_stop)
	event_base["DelayBefore"]= random.randint(rand_delaybefore_start,rand_delaybefore_stop)
	counter_service = counter_service + 1
	event = json.dumps(event_base, indent = 4)
	dict_event = json.loads(event)

	dict_timeline["TimeLineHandlers"][0]["TimeLineEvents"].append(dict_event)

	return

#@TODO
def traffic_gen_ping(type_OS,aux,dict_timeline,event_base,rand_ping_min,rand_ping_max, \
	rand_delayafter_start,rand_delayafter_stop,rand_delaybefore_start,rand_delaybefore_stop,counter_ip):

	if type_OS == 'LINUX':
		event_base["Command"]= unix_ping_command + str(random.randint(rand_ping_min,rand_ping_max))+" "+aux["reachable_vms"][counter_ip]
	elif type_OS == 'WINDOWS':
		event_base["Command"]= win_ping_command + str(random.randint(rand_ping_min,rand_ping_max))+" "+aux["reachable_vms"][counter_ip]
	elif type_OS == 'TEST':
		event_base["Command"]= ping_command + str(random.randint(rand_ping_min,rand_ping_max))+" "+aux["reachable_vms"][counter_ip]
	
	event_base["Command"]=ping_command+str(random.randint(rand_ping_min,rand_ping_max))+" "+aux["reachable_vms"][counter_ip]
	event_base["DelayAfter"]= random.randint(rand_delayafter_start,rand_delayafter_stop)
	event_base["DelayBefore"]= random.randint(rand_delaybefore_start,rand_delaybefore_stop)
	
	#counter_ip = counter_ip + 1

	event = json.dumps(event_base, indent = 4)
	dict_event = json.loads(event)

	dict_timeline["TimeLineHandlers"][0]["TimeLineEvents"].append(dict_event)

	return 

def traffic_gen_traceroute(type_OS,aux,dict_timeline,event_base,rand_ping_min,rand_ping_max,\
	rand_delayafter_start,rand_delayafter_stop,rand_delaybefore_start,\
	rand_delaybefore_stop,counter_ip):

	if type_OS == 'LINUX':
		event_base["Command"]= unix_traceroute_command + str(random.randint(rand_ping_min,rand_ping_max))+" "+aux["reachable_vms"][counter_ip]
	elif type_OS == 'WINDOWS':
		event_base["Command"]= win_traceroute_command + str(random.randint(rand_ping_min,rand_ping_max))+" "+aux["reachable_vms"][counter_ip]
	elif type_OS == 'TEST':
		event_base["Command"]= traceroute_command + str(random.randint(rand_ping_min,rand_ping_max))+" "+aux["reachable_vms"][counter_ip]

	event_base["DelayAfter"]= random.randint(rand_delayafter_start,rand_delayafter_stop)
	event_base["DelayBefore"]= random.randint(rand_delaybefore_start,rand_delaybefore_stop)
	
	#counter_ip = counter_ip + 1

	event = json.dumps(event_base, indent = 4)
	dict_event = json.loads(event)

	dict_timeline["TimeLineHandlers"][0]["TimeLineEvents"].append(dict_event)

	return 

#@TODO
def traffic_gen_ssh(type_OS,dict_timeline,event_base,ip_servidor,rand_delayafter_start,\
	rand_delayafter_stop,rand_delaybefore_start,rand_delaybefore_stop,counter_service):

	if type_OS == 'LINUX':
		event_base["Command"]= unix_ssh_command + ip_servidor + " exit"
	elif type_OS == 'WINDOWS':
		event_base["Command"]= win_ssh_command + ip_servidor + " exit"
	elif type_OS == 'TEST':
		event_base["Command"]= ssh_command + ip_servidor + " exit"

	event_base["DelayAfter"]= random.randint(rand_delayafter_start,rand_delayafter_stop)
	event_base["DelayBefore"]= random.randint(rand_delaybefore_start,rand_delaybefore_stop)
	
	counter_service = counter_service + 1
	
	event = json.dumps(event_base, indent = 4)
	dict_event = json.loads(event)

	dict_timeline["TimeLineHandlers"][0]["TimeLineEvents"].append(dict_event)

	return


def traffic_gen_scp(type_OS,dict_timeline,event_base,ip_servidor,rand_delayafter_start,\
	rand_delayafter_stop,rand_delaybefore_start,rand_delaybefore_stop,counter_service):

# NOTA: Dependemos del tipo de SO del equipo destino para pasar correctamente la ruta
# 	UNIX 	-> 	UNIX
# 	UNIX 	-> 	WINDOWS
# 	WINDOWS	-> 	WINDOWS
# 	WINDOWS -> 	UNIX

	if type_OS == 'LINUX':
		event_base["Command"]= unix_scp_command + ip_servidor + ":/home/"+ mgmt_user
	elif type_OS == 'WINDOWS':
		event_base["Command"]= win_scp_command + ip_servidor + ":/home/"+ mgmt_user
	elif type_OS == 'TEST':
		event_base["Command"]= scp_command + ip_servidor + ":/home/"+ mgmt_user

	event_base["DelayAfter"]= random.randint(rand_delayafter_start,rand_delayafter_stop)
	event_base["DelayBefore"]= random.randint(rand_delaybefore_start,rand_delaybefore_stop)

	counter_service = counter_service + 1

	event = json.dumps(event_base, indent = 4)
	dict_event = json.loads(event)

	dict_timeline["TimeLineHandlers"][0]["TimeLineEvents"].append(dict_event)

	return

def traffic_gen_nmap(type_OS,aux,dict_timeline,event_base, \
	rand_delayafter_start,rand_delayafter_stop,rand_delaybefore_start,rand_delaybefore_stop,counter_ip):

	if type_OS == 'LINUX':
		event_base["Command"]= unix_nmap_command+" "+aux["reachable_vms"][counter_ip]
	elif type_OS == 'WINDOWS':
		event_base["Command"]= win_nmap_command+" "+aux["reachable_vms"][counter_ip]
	elif type_OS == 'TEST':
		event_base["Command"]= nmap_command+" "+aux["reachable_vms"][counter_ip]

	event_base["DelayAfter"]= random.randint(rand_delayafter_start,rand_delayafter_stop)
	event_base["DelayBefore"]= random.randint(rand_delaybefore_start,rand_delaybefore_stop)
	
	#counter_ip = counter_ip + 1

	event = json.dumps(event_base, indent = 4)
	dict_event = json.loads(event)

	dict_timeline["TimeLineHandlers"][0]["TimeLineEvents"].append(dict_event)

	return

#################################################################################################
################################## [COBRA] Trafico elastico #####################################
#################################################################################################


def traffic_gen_smtp(type_OS,dict_timeline,event_base,ip_servidor,rand_delayafter_start,\
	rand_delayafter_stop,rand_delaybefore_start,rand_delaybefore_stop,counter_service):

	if type_OS == 'LINUX':
		event_base["Command"]= unix_smtp_command + ip_servidor
	elif type_OS == 'WINDOWS':
		event_base["Command"]= win_smtp_command + ip_servidor
	elif type_OS == 'TEST':
		event_base["Command"]= smtp_command + ip_servidor

	event_base["DelayAfter"]= random.randint(rand_delayafter_start,rand_delayafter_stop)
	event_base["DelayBefore"]= random.randint(rand_delaybefore_start,rand_delaybefore_stop)

	counter_service = counter_service + 1

	event = json.dumps(event_base, indent = 4)
	dict_event = json.loads(event)

	dict_timeline["TimeLineHandlers"][0]["TimeLineEvents"].append(dict_event)

	return

def traffic_gen_file_smpt(type_OS,dict_timeline,event_base,ip_servidor,rand_delayafter_start,\
	rand_delayafter_stop,rand_delaybefore_start,rand_delaybefore_stop,counter_service):

	if type_OS == 'LINUX':
		event_base["Command"]= unix_smtp_file_command + ip_servidor
	elif type_OS == 'WINDOWS':
		event_base["Command"]= win_smtp_file_command + ip_servidor
	elif type_OS == 'TEST':
		event_base["Command"]= smtp_file_command + ip_servidor

	event_base["DelayAfter"]= random.randint(rand_delayafter_start,rand_delayafter_stop)
	event_base["DelayBefore"]= random.randint(rand_delaybefore_start,rand_delaybefore_stop)

	counter_service = counter_service + 1

	event = json.dumps(event_base, indent = 4)
	dict_event = json.loads(event)

	dict_timeline["TimeLineHandlers"][0]["TimeLineEvents"].append(dict_event)

	return

def traffic_gen_file_ssh(type_OS,dict_timeline,event_base,ip_servidor,rand_delayafter_start,\
	rand_delayafter_stop,rand_delaybefore_start,rand_delaybefore_stop,counter_service):

	if type_OS == 'LINUX':
		event_base["Command"]= unix_ssh_file_command + ip_servidor
	elif type_OS == 'WINDOWS':
		event_base["Command"]= win_ssh_file_command + ip_servidor
	elif type_OS == 'TEST':
		event_base["Command"]= ssh_file_command + ip_servidor

	event_base["DelayAfter"]= random.randint(rand_delayafter_start,rand_delayafter_stop)
	event_base["DelayBefore"]= random.randint(rand_delaybefore_start,rand_delaybefore_stop)

	counter_service = counter_service + 1

	event = json.dumps(event_base, indent = 4)
	dict_event = json.loads(event)

	dict_timeline["TimeLineHandlers"][0]["TimeLineEvents"].append(dict_event)

	return

def traffic_gen_bbdd_postgres(type_OS,dict_timeline,event_base,ip_servidor,rand_delayafter_start,\
	rand_delayafter_stop,rand_delaybefore_start,rand_delaybefore_stop,counter_service):

	if type_OS == 'LINUX':
		event_base["Command"]= unix_bbdd_postgres_command(ip_servidor)
	elif type_OS == 'WINDOWS':
		event_base["Command"]= win_bbdd_postgres_command + ip_servidor
	elif type_OS == 'TEST':
		event_base["Command"]= bbdd_postgres_command(ip_servidor)

	event_base["DelayAfter"]= random.randint(rand_delayafter_start,rand_delayafter_stop)
	event_base["DelayBefore"]= random.randint(rand_delaybefore_start,rand_delaybefore_stop)

	counter_service = counter_service + 1

	event = json.dumps(event_base, indent = 4)
	dict_event = json.loads(event)

	dict_timeline["TimeLineHandlers"][0]["TimeLineEvents"].append(dict_event)

	return

def traffic_gen_bbdd_mysql(type_OS,dict_timeline,event_base,ip_servidor,rand_delayafter_start,\
	rand_delayafter_stop,rand_delaybefore_start,rand_delaybefore_stop,counter_service):

	if type_OS == 'LINUX':
		event_base["Command"]= unix_bbdd_mysql_command(ip_servidor)
	elif type_OS == 'WINDOWS':
		event_base["Command"]= win_bbdd_mysql_command + ip_servidor
	elif type_OS == 'TEST':
		event_base["Command"]= bbdd_mysql_command(ip_servidor)


	event_base["DelayAfter"]= random.randint(rand_delayafter_start,rand_delayafter_stop)
	event_base["DelayBefore"]= random.randint(rand_delaybefore_start,rand_delaybefore_stop)

	counter_service = counter_service + 1

	event = json.dumps(event_base, indent = 4)
	dict_event = json.loads(event)

	dict_timeline["TimeLineHandlers"][0]["TimeLineEvents"].append(dict_event)

	return

def traffic_gen_bbdd_mongo(type_OS,dict_timeline,event_base,ip_servidor,rand_delayafter_start,\
	rand_delayafter_stop,rand_delaybefore_start,rand_delaybefore_stop,counter_service):

	if type_OS == 'LINUX':
		event_base["Command"]= unix_bbdd_mongo_command + ip_servidor
	elif type_OS == 'WINDOWS':
		event_base["Command"]= win_bbdd_mongo_command + ip_servidor
	elif type_OS == 'TEST':
		event_base["Command"]= bbdd_mongo_command + ip_servidor

	event_base["DelayAfter"]= random.randint(rand_delayafter_start,rand_delayafter_stop)
	event_base["DelayBefore"]= random.randint(rand_delaybefore_start,rand_delaybefore_stop)
	counter_service = counter_service + 1
	event = json.dumps(event_base, indent = 4)
	dict_event = json.loads(event)

	dict_timeline["TimeLineHandlers"][0]["TimeLineEvents"].append(dict_event)

	return


#################################################################################################
################################## [COBRA] Trafico Streaming ####################################
#################################################################################################


def traffic_gen_streaming_1(type_OS,dict_timeline,event_base,ip_servidor,rand_delayafter_start,\
	rand_delayafter_stop,rand_delaybefore_start,rand_delaybefore_stop,counter_service):

	if type_OS == 'LINUX':
		event_base["Command"]= unix_streaming_1_command + ip_servidor
	elif type_OS == 'WINDOWS':
		event_base["Command"]= win_streaming_1_command + ip_servidor
	elif type_OS == 'TEST':
		event_base["Command"]= streaming_1_command + ip_servidor

	event_base["DelayAfter"]= random.randint(rand_delayafter_start,rand_delayafter_stop)
	event_base["DelayBefore"]= random.randint(rand_delaybefore_start,rand_delaybefore_stop)

	counter_service = counter_service + 1

	event = json.dumps(event_base, indent = 4)
	dict_event = json.loads(event)

	dict_timeline["TimeLineHandlers"][0]["TimeLineEvents"].append(dict_event)

	return

def traffic_gen_streaming_2(type_OS,dict_timeline,event_base,ip_servidor,rand_delayafter_start,\
	rand_delayafter_stop,rand_delaybefore_start,rand_delaybefore_stop,counter_service):

	if type_OS == 'LINUX':
		event_base["Command"]= unix_streaming_2_command + ip_servidor
	elif type_OS == 'WINDOWS':
		event_base["Command"]= win_streaming_2_command + ip_servidor
	elif type_OS == 'TEST':
		event_base["Command"]= streaming_2_command + ip_servidor

	event_base["DelayAfter"]= random.randint(rand_delayafter_start,rand_delayafter_stop)
	event_base["DelayBefore"]= random.randint(rand_delaybefore_start,rand_delaybefore_stop)

	counter_service = counter_service + 1

	event = json.dumps(event_base, indent = 4)
	dict_event = json.loads(event)

	dict_timeline["TimeLineHandlers"][0]["TimeLineEvents"].append(dict_event)

	return


#################################################################################################
################################## [COBRA] Trafico conversacional ###############################
#################################################################################################


def traffic_gen_voip(type_OS,dict_timeline,event_base,ip_servidor,rand_delayafter_start,\
	rand_delayafter_stop,rand_delaybefore_start,rand_delaybefore_stop,counter_service):

	if type_OS == 'LINUX':
		event_base["Command"]= unix_voip_command + ip_servidor
	elif type_OS == 'WINDOWS':
		event_base["Command"]= win_voip_command + ip_servidor
	elif type_OS == 'TEST':
		event_base["Command"]= voip_command + ip_servidor

	event_base["DelayAfter"]= random.randint(rand_delayafter_start,rand_delayafter_stop)
	event_base["DelayBefore"]= random.randint(rand_delaybefore_start,rand_delaybefore_stop)

	counter_service = counter_service + 1

	event = json.dumps(event_base, indent = 4)
	dict_event = json.loads(event)

	dict_timeline["TimeLineHandlers"][0]["TimeLineEvents"].append(dict_event)

	return

def traffic_gen_videoconference(type_OS,dict_timeline,event_base,ip_servidor,rand_delayafter_start,\
	rand_delayafter_stop,rand_delaybefore_start,rand_delaybefore_stop,counter_service):

	if type_OS == 'LINUX':
		event_base["Command"]= unix_videoconference_command + ip_servidor
	elif type_OS == 'WINDOWS':
		event_base["Command"]= win_videoconference_command + ip_servidor
	elif type_OS == 'TEST':
		event_base["Command"]= videoconference_command + ip_servidor

	event_base["DelayAfter"]= random.randint(rand_delayafter_start,rand_delayafter_stop)
	event_base["DelayBefore"]= random.randint(rand_delaybefore_start,rand_delaybefore_stop)

	counter_service = counter_service + 1

	event = json.dumps(event_base, indent = 4)
	dict_event = json.loads(event)

	dict_timeline["TimeLineHandlers"][0]["TimeLineEvents"].append(dict_event)

	return

def traffic_gen_remote_desktop(type_OS,dict_timeline,event_base,ip_servidor,rand_delayafter_start,\
	rand_delayafter_stop,rand_delaybefore_start,rand_delaybefore_stop,counter_service):

	if type_OS == 'LINUX':
		event_base["Command"]= unix_remote_desktop_command + ip_servidor
	elif type_OS == 'WINDOWS':
		event_base["Command"]= win_remote_desktop_command + ip_servidor
	elif type_OS == 'TEST':
		event_base["Command"]= remote_desktop_command + ip_servidor

	event_base["DelayAfter"]= random.randint(rand_delayafter_start,rand_delayafter_stop)
	event_base["DelayBefore"]= random.randint(rand_delaybefore_start,rand_delaybefore_stop)

	counter_service = counter_service + 1

	event = json.dumps(event_base, indent = 4)
	dict_event = json.loads(event)

	dict_timeline["TimeLineHandlers"][0]["TimeLineEvents"].append(dict_event)

	return


